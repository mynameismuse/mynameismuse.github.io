/**
 * 处理 classList
 * 增加 add remove 方法
 */
;(function () {
  var element = document.createElement('div')
  if ('classList' in element) return

  Object.defineProperty(Element.prototype, 'classList', {
    get: function () {
      var _this = this
      var className = _this.className
      var classList = className.split(' ')
      return {
        add: function (str) {
          if (classList.indexOf(str) >= 0) return
          classList.push(str)
          _this.className = classList.join(' ')
        },
        remove: function (str) {
          var newList = classList.filter(function (c) {
            return c !== str
          })
          _this.className = newList.join(' ')
        }
      }
    }
  })
})()

/**
 * 处理 addEventListener
 * https://gist.github.com/xgqfrms-GitHub/8f1071b522a6f54316215d6aa37f5706
 */
;(function () {
  if (!Event.prototype.preventDefault) {
    Event.prototype.preventDefault = function () {
      this.returnValue = false
    }
  }
  if (!Event.prototype.stopPropagation) {
    Event.prototype.stopPropagation = function () {
      this.cancelBubble = true
    }
  }
  if (!Element.prototype.addEventListener) {
    var eventListeners = []

    var addEventListener = function (type, listener /*, useCapture (will be ignored) */) {
      var self = this
      var wrapper = function (e) {
        e.target = e.srcElement
        e.currentTarget = self
        if (typeof listener.handleEvent != 'undefined') {
          listener.handleEvent(e)
        } else {
          listener.call(self, e)
        }
      }
      if (type == 'DOMContentLoaded') {
        var wrapper2 = function (e) {
          if (document.readyState == 'complete') {
            wrapper(e)
          }
        }
        document.attachEvent('onreadystatechange', wrapper2)
        eventListeners.push({object: this, type: type, listener: listener, wrapper: wrapper2})

        if (document.readyState == 'complete') {
          var e = new Event()
          e.srcElement = window
          wrapper2(e)
        }
      } else {
        this.attachEvent('on' + type, wrapper)
        eventListeners.push({object: this, type: type, listener: listener, wrapper: wrapper})
      }
    }
    var removeEventListener = function (type, listener /*, useCapture (will be ignored) */) {
      var counter = 0
      while (counter < eventListeners.length) {
        var eventListener = eventListeners[counter]
        if (eventListener.object == this && eventListener.type == type && eventListener.listener == listener) {
          if (type == 'DOMContentLoaded') {
            this.detachEvent('onreadystatechange', eventListener.wrapper)
          } else {
            this.detachEvent('on' + type, eventListener.wrapper)
          }
          eventListeners.splice(counter, 1)
          break
        }
        ++counter
      }
    }
    Element.prototype.addEventListener = addEventListener
    Element.prototype.removeEventListener = removeEventListener
    if (HTMLDocument) {
      HTMLDocument.prototype.addEventListener = addEventListener
      HTMLDocument.prototype.removeEventListener = removeEventListener
    }
    if (Window) {
      Window.prototype.addEventListener = addEventListener
      Window.prototype.removeEventListener = removeEventListener
    }
  }
})()